import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  ShieldCheck, 
  FileText, 
  Smartphone, 
  Printer, 
  Users, 
  ChevronRight, 
  ChevronLeft,
  Star,
  AlertCircle,
  Lightbulb,
  Clock,
  Zap,
  Gift,
  Trophy,
  Calendar,
  ArrowRight,
  X
} from 'lucide-react';

// --- Components ---

const ScrollReveal = ({ children, className = "" }: { children: React.ReactNode, className?: string }) => (
  <motion.div
    initial={{ opacity: 0, y: 40 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-50px" }}
    transition={{ duration: 0.7, ease: "easeOut" }}
    className={className}
  >
    {children}
  </motion.div>
);

const TopBanner = () => {
  const [timeLeft, setTimeLeft] = useState(10 * 60);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="bg-indigo-900 text-amber-400 py-2 px-4 text-center font-bold text-xs sm:text-sm sticky top-0 z-50 shadow-md tracking-wide">
      ⚡ OFERTA RELÂMPAGO: {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')} ⚡
    </div>
  );
};

const NotificationToast = () => {
  const [visible, setVisible] = useState(false);
  const [currentNotification, setCurrentNotification] = useState(0);

  const notifications = [
    { name: 'Profª Cláudia S.', city: 'Rio de Janeiro, RJ', action: 'comprou agora' },
    { name: 'Profª Fernanda L.', city: 'Porto Alegre, RS', action: 'comprou agora' },
    { name: 'Profª Beatriz C.', city: 'Salvador, BA', action: 'comprou agora' },
    { name: 'Profª Juliana M.', city: 'Brasília, DF', action: 'comprou agora' },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setVisible(true);
      setTimeout(() => setVisible(false), 4000);
      setCurrentNotification((prev) => (prev + 1) % notifications.length);
    }, 8000);
    
    setTimeout(() => setVisible(true), 2000);
    setTimeout(() => setVisible(false), 6000);

    return () => clearInterval(timer);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div 
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.9 }}
          className="fixed bottom-4 left-4 z-50 bg-white rounded-lg shadow-2xl p-2 sm:p-3 flex items-center gap-2 sm:gap-3 border border-indigo-50 max-w-[220px] sm:max-w-[260px]"
        >
          <div className="bg-emerald-100 p-1.5 sm:p-2 rounded-full shrink-0">
            <CheckCircle2 className="text-emerald-600 w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs sm:text-sm font-bold text-slate-800 truncate">{notifications[currentNotification].name}</p>
            <p className="text-[10px] sm:text-xs text-slate-500 truncate">{notifications[currentNotification].city}</p>
            <p className="text-[10px] sm:text-xs text-emerald-600 mt-0.5 font-semibold truncate">
              {notifications[currentNotification].action}
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

const Hero = () => (
  <section className="pt-16 pb-24 px-4 bg-slate-50 text-slate-900 relative overflow-hidden">
    <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-indigo-100/50 via-slate-50 to-slate-50 pointer-events-none"></div>
    
    <ScrollReveal className="max-w-5xl mx-auto text-center relative z-10">
      <div className="inline-flex items-center gap-2 bg-indigo-100 text-indigo-800 px-4 py-1.5 rounded-full text-sm font-bold mb-8 tracking-wide uppercase shadow-sm border border-indigo-200">
        <Star className="w-4 h-4 fill-indigo-800" />
        Para Professores do Ensino Fundamental
      </div>
      
      <div className="flex justify-center mb-6">
        <img 
          src="https://i.ibb.co/mCzxwMmL/Chat-GPT-Image-7-de-mar-de-2026-14-50-50.png" 
          alt="Headline Image" 
          className="max-w-full h-auto mix-blend-multiply"
          referrerPolicy="no-referrer"
        />
      </div>

      <h1 className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-slate-900 leading-[1.1] mb-5 max-w-4xl mx-auto">
        Prenda a Atenção da Turma com <span className="text-indigo-600">500 Dinâmicas de Matemática</span>
      </h1>
      
      <p className="text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto mb-10 leading-relaxed font-medium">
        <strong className="text-slate-900">Material pronto para imprimir e aplicar.</strong> Acabe com o tédio nas aulas e o estresse do planejamento.
      </p>
      
      <div className="relative max-w-sm mx-auto mb-12 group">
        <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-blue-500 rounded-2xl blur opacity-20 group-hover:opacity-30 transition duration-500"></div>
        <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-slate-200 bg-white aspect-[9/16] flex items-center justify-center">
          <iframe
            src="https://fast.wistia.net/embed/iframe/jg16sggw81?videoFoam=true"
            title="VSL Video"
            className="w-full h-full"
            allow="autoplay; fullscreen"
            allowFullScreen
          />
        </div>
      </div>
      
      <div className="flex flex-col items-center gap-4">
        <button 
          onClick={() => document.getElementById('premium-plan')?.scrollIntoView({ behavior: 'smooth' })}
          className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-white font-black py-5 px-10 rounded-xl text-lg sm:text-xl shadow-lg shadow-emerald-500/30 transition-all hover:-translate-y-1 active:scale-95 uppercase tracking-wide flex items-center justify-center gap-3"
        >
          QUERO MEU ACESSO AGORA
          <ArrowRight className="w-6 h-6" />
        </button>
        
        <div className="flex items-center gap-2 text-slate-500 font-medium text-sm">
          <ShieldCheck className="w-5 h-5 text-emerald-500" />
          <span>Compra 100% segura. Acesso imediato no email.</span>
        </div>
      </div>
    </ScrollReveal>
  </section>
);

const PainPoints = () => (
  <section className="py-20 px-4 bg-white border-y border-slate-100">
    <ScrollReveal className="max-w-4xl mx-auto">
      <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 text-center mb-12 leading-tight">
        A rotina em sala de aula está <span className="text-red-600">desgastante?</span>
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
        {[
          { icon: <Users className="w-6 h-6 text-red-500" />, text: "Alunos dispersos e conversando durante a explicação" },
          { icon: <Clock className="w-6 h-6 text-red-500" />, text: "Horas do seu fim de semana perdidas planejando aulas" },
          { icon: <Lightbulb className="w-6 h-6 text-red-500" />, text: "Falta de ideias novas para prender a atenção da turma" },
          { icon: <AlertCircle className="w-6 h-6 text-red-500" />, text: "Frustração por ensinar e os alunos não absorverem" },
        ].map((item, i) => (
          <div 
            key={i}
            className="bg-slate-50 p-6 rounded-2xl border border-slate-100 flex items-start gap-4 hover:border-red-100 transition-colors"
          >
            <div className="bg-red-50 p-3 rounded-xl shrink-0">
              {item.icon}
            </div>
            <span className="text-slate-700 font-medium leading-relaxed">
              {item.text}
            </span>
          </div>
        ))}
      </div>
    </ScrollReveal>
  </section>
);

const Solution = () => (
  <section className="py-24 px-4 bg-indigo-900 text-white overflow-hidden relative">
    <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600 rounded-full blur-[128px] opacity-50 -mr-32 -mt-32 pointer-events-none"></div>
    <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-600 rounded-full blur-[128px] opacity-50 -ml-32 -mb-32 pointer-events-none"></div>

    <ScrollReveal className="max-w-5xl mx-auto relative z-10">
      <div className="flex flex-col md:flex-row items-center gap-12">
        <div className="md:w-1/2">
          <div className="inline-block bg-indigo-800/50 border border-indigo-400/30 text-indigo-200 px-4 py-1.5 rounded-full text-sm font-bold mb-6 tracking-wide uppercase">
            A Solução Definitiva
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-6 leading-tight">
            O Maior Acervo de <br />
            <span className="text-amber-400">Dinâmicas Matemáticas</span>
          </h2>
          <p className="text-lg text-indigo-100 mb-8 leading-relaxed">
            Material prático e testado para transformar a matemática em uma experiência visual e lúdica.
          </p>
          
          <div className="space-y-4 mb-10">
            {[
              "Atividades alinhadas à BNCC",
              "Exercícios para imprimir e usar na hora",
              "Jogos que estimulam o raciocínio lógico",
              "Do 1º ao 9º ano do Ensino Fundamental"
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="bg-emerald-500/20 p-1 rounded-full shrink-0">
                  <CheckCircle2 className="text-emerald-400 w-5 h-5" />
                </div>
                <span className="text-indigo-50 font-medium">{item}</span>
              </div>
            ))}
          </div>
          
          <button 
            onClick={() => document.getElementById('premium-plan')?.scrollIntoView({ behavior: 'smooth' })}
            className="w-full sm:w-auto bg-amber-500 hover:bg-amber-400 text-indigo-950 font-black py-4 px-8 rounded-xl text-lg shadow-lg shadow-amber-500/20 transition-all hover:-translate-y-1 active:scale-95 uppercase tracking-wide"
          >
            QUERO VER O MATERIAL
          </button>
        </div>
        
        <div className="md:w-1/2 relative w-full">
          <div className="bg-white/5 p-4 rounded-3xl border border-white/10 backdrop-blur-sm">
            <img 
              src="https://i.ibb.co/sk5fFKT/Chat-GPT-Image-7-de-mar-de-2026-01-36-47.png" 
              alt="Atividades matemáticas" 
              className="rounded-2xl shadow-2xl w-full h-auto"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute -bottom-6 -right-2 sm:-right-6 bg-amber-400 text-indigo-950 p-4 sm:p-6 rounded-2xl shadow-xl font-black text-center rotate-3 border-2 border-white">
            <p className="text-xs uppercase font-bold">Mais de</p>
            <p className="text-3xl sm:text-4xl">500</p>
            <p className="text-xs uppercase font-bold">Dinâmicas</p>
          </div>
        </div>
      </div>
    </ScrollReveal>
  </section>
);

const WhatYouReceive = () => (
  <section className="py-24 px-4 bg-slate-50">
    <ScrollReveal className="max-w-5xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">O que você vai receber exatamente?</h2>
        <p className="text-slate-600 max-w-2xl mx-auto text-lg">Tudo o que você precisa para o ano letivo inteiro em um só lugar.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        {[
          {
            icon: <Printer className="w-6 h-6 text-indigo-600" />,
            title: "Atividades em PDF",
            desc: "Centenas de folhas de exercícios prontas para imprimir e entregar aos alunos.",
            img: "https://i.ibb.co/QF2HDwjF/Chat-GPT-Image-7-de-mar-de-2026-02-01-15.png"
          },
          {
            icon: <Smartphone className="w-6 h-6 text-indigo-600" />,
            title: "Acesso Imediato",
            desc: "Baixe tudo no seu celular, tablet ou computador logo após a compra.",
            img: "https://i.ibb.co/gpJBy4m/Chat-GPT-Image-7-de-mar-de-2026-02-06-11.png"
          },
          {
            icon: <Trophy className="w-6 h-6 text-indigo-600" />,
            title: "Jogos Lúdicos",
            desc: "Dinâmicas em grupo e jogos de tabuleiro matemáticos para engajar a turma.",
            img: "https://i.ibb.co/JRvYsT4R/Chat-GPT-Image-7-de-mar-de-2026-02-10-06.png"
          }
        ].map((item, i) => (
          <div key={i} className="bg-white rounded-2xl overflow-hidden shadow-md border border-slate-100 group hover:shadow-xl transition-all hover:-translate-y-1">
            <div className="h-48 overflow-hidden relative">
              <img src={item.img} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent"></div>
              <div className="absolute bottom-4 left-4 bg-white p-2 rounded-lg shadow-sm">
                {item.icon}
              </div>
            </div>
            <div className="p-6">
              <h3 className="text-lg font-bold text-slate-800 mb-2">{item.title}</h3>
              <p className="text-slate-600 text-sm leading-relaxed">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>
      
      <div className="text-center">
        <button 
          onClick={() => document.getElementById('premium-plan')?.scrollIntoView({ behavior: 'smooth' })}
          className="inline-flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-4 px-8 rounded-xl text-lg shadow-lg shadow-emerald-500/20 transition-all hover:-translate-y-1 active:scale-95 uppercase tracking-wide"
        >
          SIM, EU QUERO ESSE MATERIAL
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </ScrollReveal>
  </section>
);

const Bonuses = () => (
  <section className="py-24 px-4 bg-slate-900 text-white relative overflow-hidden">
    <div className="absolute top-0 right-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5 pointer-events-none"></div>
    <ScrollReveal className="max-w-5xl mx-auto relative z-10">
      <div className="text-center mb-16">
        <div className="inline-block bg-amber-500 text-slate-900 px-4 py-1.5 rounded-full text-sm font-bold mb-6 uppercase tracking-widest shadow-md">
          Bônus Exclusivos
        </div>
        <h2 className="text-3xl sm:text-4xl font-bold mb-4">Comprando hoje, você ganha:</h2>
        <p className="text-slate-400 text-lg">Estes materiais complementares são vendidos separadamente, mas hoje serão seus de graça.</p>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {[
          { title: "50 Atividades de Reforço", value: "R$ 47,00", image: "https://i.ibb.co/HDTjRF4L/Captura-de-tela-2026-03-07-022352.png" },
          { title: "100 Problemas Prontos", value: "R$ 37,00", image: "https://i.ibb.co/nM4XbChJ/Captura-de-tela-2026-03-07-022419.png" },
          { title: "Jogos Rápidos", value: "R$ 27,00", image: "https://i.ibb.co/276WBg7D/Captura-de-tela-2026-03-07-022426.png" },
          { title: "30 Dinâmicas Quebra-Gelo", value: "R$ 19,00", image: "https://i.ibb.co/zTNfy7q9/Captura-de-tela-2026-03-07-022443.png" },
          { title: "Desafios de Raciocínio", value: "R$ 39,00", image: "https://i.ibb.co/6CcVsrT/Captura-de-tela-2026-03-07-022504.png" }
        ].map((bonus, i) => (
          <div key={i} className="bg-slate-800 p-5 rounded-2xl border border-slate-700 flex flex-col items-center text-center">
            <div className="w-full aspect-video mb-5 rounded-xl overflow-hidden relative">
              <img src={bonus.image} alt={bonus.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              <div className="absolute top-2 left-2 bg-amber-500 text-slate-900 text-xs font-bold px-2 py-1 rounded shadow-md">
                Bônus {i + 1}
              </div>
            </div>
            <h3 className="font-bold text-white mb-2 text-base">{bonus.title}</h3>
            <div className="mt-auto pt-4 w-full border-t border-slate-700 flex justify-between items-center">
              <span className="text-xs text-slate-400 line-through">De {bonus.value}</span>
              <span className="text-sm font-bold text-emerald-400 uppercase">Grátis</span>
            </div>
          </div>
        ))}
        
        <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-6 rounded-2xl border border-indigo-500 flex flex-col items-center justify-center text-center shadow-xl">
          <Gift className="w-12 h-12 mb-4 text-amber-400" />
          <h3 className="font-bold text-lg mb-2 text-white">Valor Total dos Bônus</h3>
          <p className="text-3xl font-black text-amber-400 mb-4">R$ 169,00</p>
          <p className="text-sm font-medium text-indigo-100">
            Você leva tudo isso de graça no Plano Premium.
          </p>
        </div>
      </div>
      
      <div className="text-center">
        <button 
          onClick={() => document.getElementById('premium-plan')?.scrollIntoView({ behavior: 'smooth' })}
          className="inline-flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-4 px-8 rounded-xl text-lg shadow-lg shadow-emerald-500/20 transition-all hover:-translate-y-1 active:scale-95 uppercase tracking-wide"
        >
          QUERO GARANTIR MEUS BÔNUS
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </ScrollReveal>
  </section>
);

const Testimonials = () => (
  <section className="py-24 px-4 bg-slate-50 border-t border-slate-100">
    <ScrollReveal className="max-w-6xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">Professoras que já usam e recomendam</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { name: "Profª Ana Clara", role: "Professora do 3º Ano", text: "As dinâmicas salvaram minhas aulas. Os alunos que antes não prestavam atenção agora participam de tudo.", image: "https://i.ibb.co/cKpMJcTv/ea4481f831e2a4ea8a45b861fc8532c0.jpg" },
          { name: "Profª Mariana", role: "Professora do 5º Ano", text: "Material direto ao ponto. Imprimo e aplico. A didática é excelente e os bônus são um diferencial enorme.", image: "https://i.ibb.co/TDGmtkRG/4d206aca1b74b432db37a7930973a8f9.jpg" },
          { name: "Profª Sandra", role: "Professora do 2º Ano", text: "Vale cada centavo. A organização do material me poupou horas de pesquisa no fim de semana.", image: "https://i.ibb.co/DDpZtKjp/5d758b1d6e8130a8b7d240470f2e6bae.jpg" }
        ].map((item, i) => (
          <div key={i} className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 flex flex-col h-full">
            <div className="flex gap-1 mb-4">
              {[...Array(5)].map((_, j) => (
                <Star key={j} className="w-4 h-4 text-amber-400 fill-amber-400" />
              ))}
            </div>
            <p className="text-slate-700 mb-6 flex-1 leading-relaxed">"{item.text}"</p>
            <div className="flex items-center gap-3 pt-4 border-t border-slate-50">
              {item.image ? (
                <img src={item.image} alt={item.name} className="w-10 h-10 rounded-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center font-bold text-indigo-700">
                  {item.name[6]}
                </div>
              )}
              <div>
                <div className="font-bold text-slate-900 text-sm">{item.name}</div>
                <div className="text-xs text-slate-500">{item.role}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </ScrollReveal>
  </section>
);

const Guarantee = () => (
  <section className="py-20 px-4 bg-slate-50">
    <ScrollReveal className="max-w-3xl mx-auto text-center">
      <div className="inline-flex items-center justify-center w-20 h-20 bg-indigo-100 text-indigo-600 rounded-full mb-6 shadow-sm">
        <ShieldCheck className="w-10 h-10" />
      </div>
      <h2 className="text-3xl font-bold text-slate-900 mb-4">
        Risco Zero: Garantia de 7 Dias
      </h2>
      <p className="text-lg text-slate-600 mb-6 leading-relaxed">
        Se você não gostar do material por qualquer motivo, basta enviar um email e devolvemos 100% do seu dinheiro.
      </p>
    </ScrollReveal>
  </section>
);

const Offer = ({ onBasicClick }: { onBasicClick: () => void }) => (
  <section className="py-24 px-4 bg-white relative" id="offer-section">
    <ScrollReveal className="max-w-5xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mb-4 uppercase tracking-tight">Escolha o seu plano</h2>
        <p className="text-slate-600 text-lg">Acesso imediato e vitalício após a confirmação do pagamento.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto items-center">
        {/* Plano Premium */}
        <div id="premium-plan" className="bg-indigo-900 rounded-3xl shadow-2xl border-2 border-amber-400 p-1 flex flex-col h-full relative transform md:scale-105 z-10">
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-amber-400 text-indigo-950 font-black px-4 py-1 rounded-full text-sm uppercase tracking-widest shadow-md whitespace-nowrap">
            Mais Escolhido
          </div>
          <div className="bg-indigo-900 rounded-[22px] p-8 flex flex-col h-full">
            <div className="text-center mb-6 mt-2">
              <h3 className="text-2xl font-black text-white">Plano Premium</h3>
              <p className="text-indigo-200 mt-1">Material completo + Todos os Bônus</p>
            </div>
            
            <div className="flex-1 space-y-4 mb-8">
              <div className="flex items-center gap-3 text-white">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <span className="font-medium">500 Dinâmicas de Matemática</span>
              </div>
              <div className="flex items-center gap-3 text-white">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <span className="font-medium">Acesso Vitalício</span>
              </div>
              <div className="flex items-center gap-3 text-amber-300 bg-white/5 p-2 rounded-lg border border-white/10">
                <Gift className="w-5 h-5 shrink-0" />
                <span className="font-bold">+ 5 Bônus Exclusivos (R$ 169 em bônus)</span>
              </div>
            </div>
            
            <div className="text-center mb-6">
              <div className="text-indigo-300 line-through text-sm mb-1">De R$ 97,00</div>
              <span className="text-sm font-bold text-indigo-200">Por apenas</span>
              <div className="text-5xl font-black text-white mt-1">R$ 27,90</div>
            </div>
            
            <a 
              href="https://pay.wiapy.com/re6viS2JpS"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-emerald-500 hover:bg-emerald-400 text-white font-black py-4 px-6 rounded-xl transition-all hover:-translate-y-1 shadow-lg shadow-emerald-500/20 uppercase tracking-wide text-lg flex items-center justify-center gap-2 text-center"
            >
              <span>QUERO O PLANO PREMIUM</span>
              <ArrowRight className="w-5 h-5 shrink-0" />
            </a>
          </div>
        </div>

        {/* Plano Básico */}
        <div className="bg-white rounded-3xl shadow-lg border border-slate-200 p-8 flex flex-col h-full">
          <div className="text-center mb-6">
            <h3 className="text-xl font-bold text-slate-800">Plano Básico</h3>
            <p className="text-sm text-slate-500 mt-1">Apenas o material principal</p>
          </div>
          
          <div className="flex-1 space-y-4 mb-8">
            <div className="flex items-center gap-3 text-slate-700">
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
              <span className="font-medium">500 Dinâmicas de Matemática</span>
            </div>
            <div className="flex items-center gap-3 text-slate-700">
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
              <span className="font-medium">Acesso Vitalício</span>
            </div>
            <div className="flex items-center gap-3 text-slate-400 opacity-70">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <span className="line-through">Sem os 5 Bônus Exclusivos</span>
            </div>
          </div>
          
          <div className="text-center mb-6">
            <span className="text-sm font-bold text-slate-500">Por apenas</span>
            <div className="text-4xl font-black text-slate-900 mt-1">R$ 10,00</div>
          </div>
          
          <button 
            onClick={onBasicClick}
            className="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-4 rounded-xl transition-colors uppercase text-sm tracking-wide"
          >
            Quero o Plano Básico
          </button>
        </div>
      </div>
      
      <div className="mt-12 flex justify-center gap-4 opacity-50 grayscale">
        <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" alt="Visa" className="h-5" referrerPolicy="no-referrer" />
        <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="Mastercard" className="h-6" referrerPolicy="no-referrer" />
        <img src="https://upload.wikimedia.org/wikipedia/commons/a/a2/Pix_logo.svg" alt="Pix" className="h-5" referrerPolicy="no-referrer" />
      </div>
    </ScrollReveal>
  </section>
);

const BasicPlanModal = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-white rounded-3xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 mx-4"
          >
            {/* Top accent gradient */}
            <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-amber-400 to-orange-500" />
            
            {/* Close button */}
            <button 
              onClick={onClose}
              className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 transition-colors p-1"
              aria-label="Fechar"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="p-5 sm:p-6 text-center pt-8">
              <div className="inline-flex items-center justify-center px-2.5 py-1 bg-amber-100 text-amber-700 text-[10px] font-bold uppercase tracking-wider rounded-full mb-3">
                <AlertCircle className="w-3 h-3 mr-1" />
                Oferta Exclusiva
              </div>
              
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 mb-2 leading-tight tracking-tight">
                Espere um pouco!
              </h2>
              
              <div className="text-sm text-slate-600 mb-4 leading-relaxed space-y-3">
                <p>
                  Liberamos um <strong className="text-amber-600">desconto especial</strong> para você.
                </p>
                
                <div className="bg-slate-50 border border-slate-100 rounded-2xl p-3 my-4">
                  <p className="text-slate-700 text-sm mb-1">
                    Leve o material completo com <strong className="text-slate-900">500 Dinâmicas de Matemática + todos os bônus</strong>
                  </p>
                  <div className="flex items-center justify-center gap-2 mt-2">
                    <span className="text-xs text-slate-400 line-through">De R$ 27,90</span>
                    <span className="text-[10px] font-bold text-slate-400 uppercase">por apenas</span>
                  </div>
                  <div className="text-3xl font-black text-indigo-600 mt-0.5">
                    R$ 17,90
                  </div>
                </div>
                
                <p className="text-xs text-slate-500">
                  Aproveite essa condição antes de fechar a página.
                </p>
              </div>
              
              <div className="flex flex-col gap-3 mt-5">
                <a 
                  href="https://pay.wiapy.com/t935-6KVq4"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-gradient-to-r from-emerald-500 to-emerald-400 hover:from-emerald-600 hover:to-emerald-500 text-white font-black py-3 px-4 rounded-xl text-base shadow-lg shadow-emerald-500/30 transition-all hover:-translate-y-1 active:scale-95 flex items-center justify-center gap-2 text-center animate-[pulse_2s_ease-in-out_infinite]"
                >
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <span>SIM, QUERO O DESCONTO</span>
                </a>
                
                <a 
                  href="https://pay.wiapy.com/3MvwX6Zq5B"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-slate-600 text-sm font-medium transition-colors underline underline-offset-4 py-2"
                >
                  Não, quero apenas o básico sem bônus
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const Footer = () => (
  <footer className="bg-slate-950 text-slate-400 py-12 px-4">
    <ScrollReveal className="max-w-5xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8 text-center md:text-left">
        <div>
          <h3 className="text-white font-bold mb-4 text-lg">500 Dinâmicas</h3>
          <p className="text-sm leading-relaxed opacity-80">Material didático focado em engajamento e aprendizado prático para o Ensino Fundamental.</p>
        </div>
        <div>
          <h3 className="text-white font-bold mb-4 text-lg">Links</h3>
          <ul className="text-sm space-y-2 opacity-80">
            <li><a href="#" className="hover:text-white transition-colors">Termos de Uso</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Políticas de Privacidade</a></li>
          </ul>
        </div>
        <div>
          <h3 className="text-white font-bold mb-4 text-lg">Contato</h3>
          <p className="text-sm opacity-80">suporte@dinamicasmatematica.com.br</p>
        </div>
      </div>
      <div className="pt-8 border-t border-slate-800 text-center text-xs opacity-60">
        <p>© {new Date().getFullYear()} Dinâmicas de Matemática. Todos os direitos reservados.</p>
        <p className="mt-2">Este site não faz parte do Google ou do Facebook. Não é endossado por eles.</p>
      </div>
    </ScrollReveal>
  </footer>
);

export default function App() {
  const [showBasicModal, setShowBasicModal] = useState(false);

  return (
    <div className="min-h-screen selection:bg-indigo-600 selection:text-white">
      <TopBanner />
      <Hero />
      <PainPoints />
      <Solution />
      <WhatYouReceive />
      <Bonuses />
      <Offer onBasicClick={() => setShowBasicModal(true)} />
      <Testimonials />
      <Guarantee />
      <Footer />
      <NotificationToast />

      <BasicPlanModal 
        isOpen={showBasicModal} 
        onClose={() => setShowBasicModal(false)} 
      />
    </div>
  );
}
